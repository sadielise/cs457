Our project works as expected and as defined in the project description.

Our format for chainlist files are as follows
numSS
IP port
IP port
... etc

for example....
2
129.82.46.192 55556
129.82.46.205 55556

We have included a chaingang.txt if you would like to use it. 
The two machines defined in the file are for denver and atlanta (in the CS department)


Thank you